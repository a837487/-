
import pandas as pd
import os


def process_csv_data(input_file, output_file, chunk_size=10000):
    """
    处理CSV数据（适合30万+）：
    1. 统计grants列的基金数量
    2. 拆分source_summary_stats、first_author_summary_stats、first_institution_summary_stats的关键指标
    """

    # ---------------------- 配置 ----------------------
    stats_fields = [
        'h_index',
        'i10_index',
        '2yr_h_index',
        '2yr_i10_index'
    ]

    summary_columns = {
        'source_summary_stats': 'source',
        'first_author_summary_stats': 'first_author',
        'first_institution_summary_stats': 'first_institution'
    }

    # 若输出文件已存在，先删除，避免重复写 header
    if os.path.exists(output_file):
        os.remove(output_file)

    total_rows = 0
    processed_rows = 0
    chunk_index = 0

    print(f"开始分块读取 CSV：{input_file}")

    # ---------------------- 分块读取 CSV ----------------------
    for df in pd.read_csv(input_file, chunksize=chunk_size, encoding='utf-8'):
        chunk_index += 1
        print(f"\n正在处理第 {chunk_index} 块（{len(df)} 行）")
        total_rows += len(df)

        # ---------------------- 1. 统计基金数量 ----------------------
        if 'grants' in df.columns:
            def count_grants(grants_data):
                if pd.isna(grants_data):
                    return 0
                try:
                    if isinstance(grants_data, str):
                        grants_list = eval(grants_data)
                    else:
                        grants_list = grants_data

                    if isinstance(grants_list, list):
                        return len([g for g in grants_list if isinstance(g, dict)])
                    return 0
                except:
                    return 0

            df['grants_count'] = df['grants'].apply(count_grants)
        else:
            print("警告：该分块中无 grants 列")

        # ---------------------- 2. 拆分 summary_stats ----------------------
        for col_name, prefix in summary_columns.items():
            if col_name not in df.columns:
                continue

            def extract_stats(stats_data):
                result = {field: None for field in stats_fields}
                if pd.isna(stats_data):
                    return pd.Series(result.values())

                try:
                    if isinstance(stats_data, str):
                        stats_dict = eval(stats_data)
                    else:
                        stats_dict = stats_data

                    if isinstance(stats_dict, dict):
                        for field in stats_fields:
                            result[field] = stats_dict.get(field)
                except:
                    pass

                return pd.Series(result.values())

            new_columns = [f"{prefix}_{field}" for field in stats_fields]
            df[new_columns] = df[col_name].apply(extract_stats)

        # ---------------------- 追加写入 CSV ----------------------
        df.to_csv(
            output_file,
            mode='a',
            index=False,
            header=not os.path.exists(output_file),
            encoding='utf-8'
        )

        processed_rows += len(df)
        print(f"第 {chunk_index} 块完成，累计处理 {processed_rows} 行")

    # ---------------------- 总结 ----------------------
    print("\n================ 处理完成 ================")
    print(f"总行数：{total_rows}")
    print(f"输出文件：{os.path.abspath(output_file)}")


# ---------------------- 执行入口 ----------------------
if __name__ == "__main__":
    INPUT_FILE = r"D:\所有\桌面\数据集\8.csv"
    OUTPUT_FILE = r"D:\所有\桌面\数据集\9.csv"

    process_csv_data(INPUT_FILE, OUTPUT_FILE)
