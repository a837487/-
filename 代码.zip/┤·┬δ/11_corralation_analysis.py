# -*- coding: utf-8 -*-

# ========================
# 0. 基础库
# ========================
import os
import numpy as np
import pandas as pd

from scipy.stats import mannwhitneyu, chi2_contingency, pointbiserialr

# ========================
# 1. 路径设置（只需改这里）
# ========================
DATA_PATH = r"D:/所有/桌面/11MLData.csv"
OUTPUT_DIR = r"D:/所有/桌面/analysis_results"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ========================
# 2. 读取数据
# ========================
df = pd.read_csv(DATA_PATH)

# ========================
# 3. 变量定义
# ========================
binary_vars = [
    "OA Status",
    "is_news_friendly_discipline",
    "News mentions"
]

continuous_vars = [
    "countries_distinct_count",
    "institutions_distinct_count",
    "referenced_works_count",
    "authors_count",
    "source_cited_by_count",
    "source_works_count",
    "first_author_works_count",
    "first_author_cited_by_count",
    "first_institution_works_count",
    "first_institution_cited_by_count",
    "grants_count",
    "source_h_index",
    "source_i10_index",
    "source_2yr_h_index",
    "source_2yr_i10_index",
    "first_author_h_index",
    "first_author_i10_index",
    "first_author_2yr_h_index",
    "first_author_2yr_i10_index",
    "first_institution_2yr_h_index",
    "first_institution_2yr_i10_index",
    "first_institution_h_index",
    "first_institution_i10_index",
    "Number of Dimensions citations",
    "days_since_pub"
]

# ========================
# 4. 描述性统计
# ========================
desc_results = []

for col in continuous_vars:
    for group in [0, 1]:
        subset = df[df["News mentions"] == group][col]
        desc_results.append([
            col,
            group,
            subset.count(),
            subset.mean(),
            subset.median(),
            subset.std()
        ])

desc_df = pd.DataFrame(
    desc_results,
    columns=["variable","News_mentions","n","mean","median","std"]
)

desc_df.to_csv(
    os.path.join(OUTPUT_DIR, "descriptive_statistics.csv"),
    index=False
)

# ========================
# 5. Mann–Whitney U 检验
# ========================
mwu_results = []

for col in continuous_vars:
    group1 = df[df["News mentions"] == 1][col].dropna()
    group0 = df[df["News mentions"] == 0][col].dropna()

    u_stat, p_value = mannwhitneyu(group1, group0, alternative="two-sided")

    mwu_results.append([col, u_stat, p_value])

mwu_df = pd.DataFrame(
    mwu_results,
    columns=["variable","U_statistic","p_value"]
)

mwu_df.to_csv(
    os.path.join(OUTPUT_DIR, "mann_whitney_tests.csv"),
    index=False
)

# ========================
# 6. 卡方检验
# ========================
chi2_results = []

for col in ["OA Status", "is_news_friendly_discipline"]:
    table = pd.crosstab(df[col], df["News mentions"])
    chi2, p, dof, _ = chi2_contingency(table)
    chi2_results.append([col, chi2, dof, p])

chi2_df = pd.DataFrame(
    chi2_results,
    columns=["variable","chi2_statistic","dof","p_value"]
)

chi2_df.to_csv(
    os.path.join(OUTPUT_DIR, "chi_square_tests.csv"),
    index=False
)

# ========================
# 7. 点二列相关
# ========================
pb_results = []

for col in continuous_vars:
    r, p = pointbiserialr(df["News mentions"], df[col])
    pb_results.append([col, r, p])

pb_df = pd.DataFrame(
    pb_results,
    columns=["variable","point_biserial_r","p_value"]
).sort_values("point_biserial_r", ascending=False)

pb_df.to_csv(
    os.path.join(OUTPUT_DIR, "point_biserial_correlations.csv"),
    index=False
)

# ========================
# 完成提示
# ========================
print("Analysis completed successfully.")
print(f"Results saved to: {OUTPUT_DIR}")




'''点二列绘图'''
# ======================================
# 0 导入库
# ======================================
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import pointbiserialr
from matplotlib.lines import Line2D

# ======================================
# 1 路径
# ======================================
DATA_PATH = r"D:/所有/桌面/MLdata.csv"
OUTPUT_DIR = r"D:/所有/桌面/top_journal_figures"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ======================================
# 2 绘图风格
# ======================================
sns.set_style("white")

plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False

plt.rcParams.update({
    "font.size":11,
    "axes.titlesize":14,
    "axes.labelsize":11
})

# ======================================
# 3 读取数据
# ======================================
df = pd.read_csv(DATA_PATH)

# ======================================
# 4 连续变量
# ======================================
continuous_vars = [
"countries_distinct_count",
"institutions_distinct_count",
"referenced_works_count",
"authors_count",
"source_cited_by_count",
"source_works_count",
"first_author_works_count",
"first_author_cited_by_count",
"first_institution_works_count",
"first_institution_cited_by_count",
"grants_count",
"source_h_index",
"source_i10_index",
"source_2yr_h_index",
"source_2yr_i10_index",
"first_author_h_index",
"first_author_i10_index",
"first_author_2yr_h_index",
"first_author_2yr_i10_index",
"first_institution_2yr_h_index",
"first_institution_2yr_i10_index",
"first_institution_h_index",
"first_institution_i10_index",
"Number of Dimensions citations",
"days_since_pub"
]

# ======================================
# 5 点二列相关
# ======================================
results = []

for col in continuous_vars:

    temp = df[["News mentions",col]].dropna()

    r,p = pointbiserialr(temp["News mentions"],temp[col])

    results.append([col,r,p])

pb_df = pd.DataFrame(results,columns=["variable","r","p"])

# ======================================
# 6 显著性星号
# ======================================
def star(p):

    if p < 0.001:
        return "***"
    elif p < 0.01:
        return "**"
    elif p < 0.05:
        return "*"
    else:
        return ""

pb_df["sig"] = pb_df["p"].apply(star)

# ======================================
# 7 中文变量标签
# ======================================
label_map = {

"referenced_works_count":"参考文献数量",
"Number of Dimensions citations":"被引量",
"days_since_pub":"发表时长",
"countries_distinct_count":"不同国家数量",
"institutions_distinct_count":"不同机构数量",
"grants_count":"基金数量",

"authors_count":"合作者数量",
"first_author_works_count":"第一作者作品数",
"first_author_cited_by_count":"第一作者被引量",
"first_author_h_index":"第一作者h指数",
"first_author_i10_index":"第一作者i10指数",
"first_author_2yr_h_index":"第一作者近2年h指数",
"first_author_2yr_i10_index":"第一作者近2年i10指数",

"source_works_count":"来源期刊作品数",
"source_cited_by_count":"来源期刊被引量",
"source_h_index":"来源期刊h指数",
"source_i10_index":"来源期刊i10指数",
"source_2yr_h_index":"来源期刊近2年h指数",
"source_2yr_i10_index":"来源期刊近2年i10指数",

"first_institution_works_count":"第一作者机构论文数",
"first_institution_cited_by_count":"第一作者机构被引量",
"first_institution_h_index":"第一作者机构h指数",
"first_institution_i10_index":"第一作者机构i10指数",
"first_institution_2yr_h_index":"第一作者机构近2年h指数",
"first_institution_2yr_i10_index":"第一作者机构近2年i10指数"
}

pb_df["label"] = pb_df["variable"].map(label_map)

# ======================================
# 8 维度变量
# ======================================
paper_vars = [
"referenced_works_count",
"Number of Dimensions citations",
"days_since_pub",
"countries_distinct_count",
"institutions_distinct_count",
"grants_count"
]

author_vars = [
"authors_count",
"first_author_works_count",
"first_author_cited_by_count",
"first_author_h_index",
"first_author_i10_index",
"first_author_2yr_h_index",
"first_author_2yr_i10_index"
]

journal_vars = [
"source_works_count",
"source_cited_by_count",
"source_h_index",
"source_i10_index",
"source_2yr_h_index",
"source_2yr_i10_index"
]

institution_vars = [
"first_institution_works_count",
"first_institution_cited_by_count",
"first_institution_h_index",
"first_institution_i10_index",
"first_institution_2yr_h_index",
"first_institution_2yr_i10_index"
]

# ======================================
# 9 显著性颜色
# ======================================
def sig_color(p):

    if p < 0.001:
        return "#08306B"
    elif p < 0.01:
        return "#2171B5"
    elif p < 0.05:
        return "#6BAED6"
    else:
        return "#BDBDBD"

# ======================================
# 10 绘图函数
# ======================================
def top_journal_plot(var_list,title,file_name):

    sub = pb_df[pb_df["variable"].isin(var_list)]
    sub = sub.sort_values("r")

    colors = sub["p"].apply(sig_color)

    plt.figure(figsize=(7,4.5))

    # 线
    plt.hlines(
        y=sub["label"],
        xmin=0,
        xmax=sub["r"],
        color=colors,
        linewidth=2
    )

    # 点
    plt.scatter(
        sub["r"],
        sub["label"],
        color=colors,
        s=90
    )

    # r值
    for i,row in sub.iterrows():

        plt.text(
            row["r"] + 0.005,
            row["label"],
            f"{row['r']:.4f}{row['sig']}",
            va="center",
            fontsize=10
        )

    plt.axvline(0,color="black",linewidth=1)

    plt.xlabel("相关系数 (r)")
    plt.ylabel("")
    plt.title(title)

    # 图例
    legend_elements = [

        Line2D([0],[0],marker='o',color='w',label='p < 0.001',
               markerfacecolor='#08306B',markersize=8),

        Line2D([0],[0],marker='o',color='w',label='p < 0.01',
               markerfacecolor='#2171B5',markersize=8),

        Line2D([0],[0],marker='o',color='w',label='p < 0.05',
               markerfacecolor='#6BAED6',markersize=8),

        Line2D([0],[0],marker='o',color='w',label='不显著',
               markerfacecolor='#BDBDBD',markersize=8)
    ]

    legend = plt.legend(
        handles=legend_elements,
        title="显著性水平",
        loc="lower left",
        bbox_to_anchor=(1.02,0.05),
        frameon=True,
        facecolor="#F7F7F7",
        edgecolor="#BDBDBD",
        framealpha=1
    )

    legend.get_title().set_fontsize(10)

    sns.despine()

    plt.tight_layout(rect=[0,0,0.82,1])

    plt.savefig(
        os.path.join(OUTPUT_DIR,file_name),
        dpi=600
    )

    plt.close()

# ======================================
# 11 生成图
# ======================================
top_journal_plot(
paper_vars,
" ",
"paper_dimension.png"
)

top_journal_plot(
author_vars,
" ",
"author_dimension.png"
)

top_journal_plot(
journal_vars,
" ",
"journal_dimension.png"
)

top_journal_plot(
institution_vars,
" ",
"institution_dimension.png"
)

print("图已生成")
print("输出目录:",OUTPUT_DIR)




"""分类变量绘图"""

# -*- coding: utf-8 -*-

import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
from matplotlib import font_manager
import seaborn as sns
import numpy as np

# ========================
# 1. 设置中文字体（通过字体文件，避免方框）
# ========================
font_path = r"C:\Windows\Fonts\msyh.ttc"  # 微软雅黑字体文件路径
my_font = font_manager.FontProperties(fname=font_path)

matplotlib.rcParams['font.family'] = my_font.get_name()
matplotlib.rcParams['axes.unicode_minus'] = False  # 处理负号显示

# ========================
# 2. 路径设置
# ========================
DATA_PATH = r"D:/所有/桌面/MLdata.csv"
OUTPUT_DIR = r"D:/所有/桌面/analysis_results_categorical"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ========================
# 3. 绘图风格
# ========================
sns.set_theme(style="whitegrid")
color_map = {
    "未被新闻提及": "#2C3E50",  # 蓝色
    "被新闻提及": "#95A5A6"  # 灰色
}

# ========================
# 4. 读取数据
# ========================
df = pd.read_csv(DATA_PATH)

# ========================
# 5. 分类变量列表
# ========================
categorical_vars = ["OA Status", "is_news_friendly_discipline"]
news_col = "News mentions"

# 中文标签
cn_labels = {
    "OA Status": "OA状态",
    "is_news_friendly_discipline": "是否新闻友好学科",
    "News mentions": "是否被新闻提及"
}

# 中文图例映射
news_cn_labels = {
    0: "未被新闻提及",
    1: "被新闻提及"
}


# ========================
# 6. 绘图函数（竖向柱状图）
# ========================
def plot_categorical_bar(df, col, labels, filename):
    # 计算每个分类的比例
    prop_df = pd.crosstab(df[col], df[news_col], normalize="index")
    categories = prop_df.index.tolist()
    news_categories = prop_df.columns.tolist()

    fig, ax = plt.subplots(figsize=(6, 4))
    x = np.arange(len(categories))
    bar_width = 0.35

    # 绘制柱状图
    for i, news_cat in enumerate(news_categories):
        values = prop_df[news_cat].values
        bars = ax.bar(x + i * bar_width, values, width=bar_width,
                      color=color_map[news_cn_labels[news_cat]],
                      label=news_cn_labels[news_cat])

        # 百分比标注
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width() / 2, val + 0.01, f"{val * 100:.2f}%",
                    ha="center", va="bottom", fontsize=10, fontproperties=my_font)

    # 设置坐标轴和标签
    ax.set_xticks(x + bar_width / 2)
    ax.set_xticklabels(categories, fontproperties=my_font)
    ax.set_ylabel("比例", fontproperties=my_font)
    ax.set_xlabel(labels[col], fontproperties=my_font)

    # 图例统一在右上角外侧
    ax.legend(fontsize=10, title_fontsize=10,
              loc='upper left', bbox_to_anchor=(1, 1), prop=my_font)

    sns.despine()
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, filename), dpi=300, bbox_inches='tight')
    plt.close()


# ========================
# 7. 生成中文版图
# ========================
for col in categorical_vars:
    plot_categorical_bar(df, col, cn_labels, f"proportion_{col}_cn.png")

print("分类变量竖向柱状图可视化完成（中文版），蓝色=未被新闻提及，灰色=被新闻提及。")
print(f"结果已保存到: {OUTPUT_DIR}")