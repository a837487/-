# -*- coding: utf-8 -*-

import os
import re
import xml.etree.ElementTree as ET

# ============================
# 1. 输入 / 输出文件夹
# ============================
xml_folder_path = r"D:\所有\桌面\pdf\xml"
output_folder_path = r"D:\所有\桌面\pdf\txt_output"

# 创建输出文件夹（如果不存在）
os.makedirs(output_folder_path, exist_ok=True)

# 错误日志
error_files = []

# ============================
# 2. 清理文件名非法字符
# ============================
def clean_filename(name):
    return re.sub(r'[\\/*?:"<>|]', "", name)


# ============================
# 3. 递归提取章节函数
# ============================
def extract_section(sec_element, namespace, level=1):
    content = []

    # 标题
    title = sec_element.find(f"{namespace}title")
    if title is not None:
        title_text = "".join(title.itertext()).strip()
        if title_text:
            content.append("\n" + "#" * level + " " + title_text + "\n")

    # 段落
    for p in sec_element.findall(f"{namespace}p"):
        paragraph_text = "".join(p.itertext()).strip()
        if paragraph_text:
            content.append(paragraph_text + "\n")

    # 子章节
    for sub_sec in sec_element.findall(f"{namespace}sec"):
        content.extend(extract_section(sub_sec, namespace, level + 1))

    return content


# ============================
# 4. 遍历所有XML文件
# ============================
for filename in os.listdir(xml_folder_path):

    if not filename.lower().endswith(".xml"):
        continue

    xml_file_path = os.path.join(xml_folder_path, filename)

    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()

        # 处理命名空间
        namespace = ""
        if root.tag.startswith("{"):
            namespace = root.tag.split("}")[0] + "}"

        article_content = []

        # ============================
        # 提取论文标题（用于文件名）
        # ============================
        title_element = root.find(f".//{namespace}article-title")

        if title_element is not None:
            article_title = "".join(title_element.itertext()).strip()
        else:
            article_title = os.path.splitext(filename)[0]  # 若无标题则用原文件名

        article_title = clean_filename(article_title)

        # ============================
        # 提取摘要
        # ============================
        abstract = root.find(f".//{namespace}abstract")

        if abstract is not None:
            article_content.append("# Abstract\n")

            for p in abstract.findall(f".//{namespace}p"):
                abstract_text = "".join(p.itertext()).strip()
                if abstract_text:
                    article_content.append(abstract_text + "\n")

            article_content.append("\n")

        # ============================
        # 提取正文
        # ============================
        body = root.find(f".//{namespace}body")

        if body is None:
            raise ValueError("未找到 <body> 标签")

        for sec in body.findall(f"{namespace}sec"):
            article_content.extend(extract_section(sec, namespace, level=1))

        # ============================
        # 保存txt文件
        # ============================
        txt_file_path = os.path.join(output_folder_path, article_title + ".txt")

        with open(txt_file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(article_content))

        print(f"提取成功: {filename}")

    except Exception as e:
        print(f"提取失败: {filename} | 原因: {e}")
        error_files.append(filename)


# ============================
# 5. 输出错误日志
# ============================
if error_files:
    error_log_path = os.path.join(output_folder_path, "error_log.txt")
    with open(error_log_path, "w", encoding="utf-8") as f:
        for file in error_files:
            f.write(file + "\n")

    print("以下文件提取失败，已记录至 error_log.txt")
else:
    print("所有文件提取完成，无错误文件。")