# # -*- coding: utf-8 -*-
# import pandas as pd
#
# # =========================
# # 1. 读取数据
# # =========================
# file_path = r"D:\所有\桌面\工作簿1.xlsx"  # 修改为你的路径
# df = pd.read_excel(file_path)
#
# # =========================
# # 2. 统计编码频数
# # =========================
# coding_counts = df["编码"].value_counts()
#
# # =========================
# # 3. 计算占比
# # =========================
# coding_ratio = df["编码"].value_counts(normalize=True)
#
# # =========================
# # 4. 合并为一个结果表
# # =========================
# result = pd.DataFrame({
#     "出现次数": coding_counts,
#     "占比": coding_ratio
# })
#
# # 转换为百分比格式
# result["占比"] = (result["占比"] * 100).round(2).astype(str) + "%"
#
# # =========================
# # 5. 按出现次数排序
# # =========================
# result = result.sort_values(by="出现次数", ascending=False)
#
# # =========================
# # 6. 输出结果
# # =========================
# print(result)
#
# # 保存结果
# result.to_excel("D:\所有\桌面\编码统计结果.xlsx")

import matplotlib.pyplot as plt
import pandas as pd

# 中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 字体大小
plt.rcParams.update({
    "font.size": 11,
    "axes.labelsize": 12,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10
})

# 数据
data = {
    "类别": [
        "主要研究结果","研究背景","研究结论","结果解读","已有研究成果",
        "研究对象/数据","启示与建议","总体研究内容","核心方法论","研究目标",
        "未来研究方向","技术/步骤","创新点与贡献","研究局限性",
        "研究空白","次要研究结果","研究假设"
    ],
    "占比": [30.85,14.59,10.03,8.66,6.53,5.62,3.65,3.50,2.89,2.74,2.43,2.28,1.82,1.67,1.52,1.06,0.15]
}

df = pd.DataFrame(data)

# 按占比降序排列
df = df.sort_values("占比", ascending=False)

# 画布尺寸（提高清晰度）
plt.figure(figsize=(12,8))

# 条形图
plt.barh(
    df["类别"],
    df["占比"],
    color="#1f77b4",
    height=0.65
)

# 最大值在上
plt.gca().invert_yaxis()

# 去掉多余边框
ax = plt.gca()
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)

# 网格
ax.grid(axis="x", linestyle="--", linewidth=0.6, alpha=0.4)

# 百分比标注
for i, v in enumerate(df["占比"]):
    plt.text(
        v + 0.5,
        i,
        f"{v:.2f}%",
        va="center",
        fontsize=11
    )

# 坐标轴名称
plt.xlabel("占比 (%)")
plt.ylabel("论文内容类型")

# 防止标签被截断
plt.subplots_adjust(left=0.30, bottom=0.15)

# 保存到指定路径
plt.savefig(
    r"D:\所有\桌面\Figure_1.png",
    dpi=800,
    bbox_inches="tight"
)

plt.show()