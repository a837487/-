import pandas as pd
from pymongo import MongoClient
import json
import ast
import os

# ========================== 1. MongoDB 配置 ==========================
print("正在连接MongoDB...")
client = MongoClient('mongodb://localhost:27017/')
db = client['OpenAlex-2025']
institutions_collection = db.institutions

# ========================== 2. 文件路径（CSV） ==========================
input_file_path = r"D:\所有\桌面\数据集\7.csv"
output_file_path = r"D:\所有\桌面\数据集\8.csv"

CHUNK_SIZE = 10000  #关键：分块大小（1w 比较稳）

# 若输出文件已存在，先删除（避免重复写 header）
if os.path.exists(output_file_path):
    os.remove(output_file_path)

total_records = 0
total_valid = 0
chunk_index = 0

# ========================== 3. 分块读取 CSV ==========================
print("开始分块读取 CSV 并处理...")

for df_chunk in pd.read_csv(input_file_path, chunksize=CHUNK_SIZE, encoding='utf-8'):
    chunk_index += 1
    print(f"\n正在处理第 {chunk_index} 个分块（{len(df_chunk)} 条）")

    matched_data = df_chunk.to_dict('records')
    total_records += len(matched_data)

    institution_info = []
    valid_data = []

    # ------------------ 提取机构 id ------------------
    for idx, item in enumerate(matched_data):
        try:
            doi = item.get('doi', '未知DOI')

            # authorships
            if 'authorships' not in item:
                continue

            if isinstance(item['authorships'], str):
                try:
                    item['authorships'] = ast.literal_eval(item['authorships'])
                except:
                    try:
                        item['authorships'] = json.loads(item['authorships'].replace("'", '"'))
                    except:
                        continue

            if not isinstance(item['authorships'], list) or len(item['authorships']) == 0:
                continue

            first_author = item['authorships'][0]

            # institutions
            if 'institutions' not in first_author:
                continue

            if isinstance(first_author['institutions'], str):
                try:
                    first_author['institutions'] = ast.literal_eval(first_author['institutions'])
                except:
                    try:
                        first_author['institutions'] = json.loads(first_author['institutions'].replace("'", '"'))
                    except:
                        continue

            if not isinstance(first_author['institutions'], list) or len(first_author['institutions']) == 0:
                continue

            first_inst = first_author['institutions'][0]
            inst_id = first_inst.get('id')

            if not inst_id:
                continue

            institution_info.append((inst_id, idx))

        except Exception:
            continue

    # ------------------ 批量查机构 ------------------
    inst_ids = list({x[0] for x in institution_info})

    if not inst_ids:
        continue

    institutions_data = list(
        institutions_collection.find({'id': {'$in': inst_ids}})
    )
    institutions_dict = {i['id']: i for i in institutions_data if 'id' in i}

    # ------------------ 合并机构信息 ------------------
    for inst_id, idx in institution_info:
        inst_record = institutions_dict.get(inst_id)
        if not inst_record:
            continue

        item = matched_data[idx]

        item['first_institution_id'] = inst_record.get('id')
        item['first_institution_display_name'] = inst_record.get('display_name')
        item['first_institution_type'] = inst_record.get('type')
        item['first_institution_works_count'] = inst_record.get('works_count')
        item['first_institution_cited_by_count'] = inst_record.get('cited_by_count')
        item['first_institution_summary_stats'] = inst_record.get('summary_stats')

        valid_data.append(item)

    # ------------------ 追加写入 CSV ------------------
    if valid_data:
        df_out = pd.DataFrame(valid_data)
        df_out.to_csv(
            output_file_path,
            mode='a',
            index=False,
            header=not os.path.exists(output_file_path),
            encoding='utf-8'
        )

        total_valid += len(valid_data)

    print(f"第 {chunk_index} 块完成：有效 {len(valid_data)} 条")

# ========================== 4. 总结 ==========================
print("\n================= 处理完成 =================")
print(f"总读取论文数：{total_records}")
print(f"成功关联机构的论文数：{total_valid}")
print(f"输出文件：{output_file_path}")
