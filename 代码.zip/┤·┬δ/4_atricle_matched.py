import pandas as pd
from pymongo import MongoClient
import os

def main():
    # -------------------------- 配置项（可根据实际情况修改） --------------------------
    mongo_uri = 'mongodb://localhost:27017/'
    db_name = 'OpenAlex-2025'
    collection_name = 'works'

    input_file_path = r"D:\所有\桌面\数据集\4.csv"
    output_file_path = r"D:\所有\桌面\数据集\5.csv"

    chunk_size = 50000  # 关键：每次处理 5 万行
    # ---------------------------------------------------------------------------------

    try:
        # 1. 连接MongoDB
        print("正在连接MongoDB...")
        client = MongoClient(mongo_uri)
        db = client[db_name]
        collection = db[collection_name]
        print(f"MongoDB连接成功，已连接到 {db_name}.{collection_name}")

        # 2. 检查输入文件
        if not os.path.exists(input_file_path):
            raise FileNotFoundError("输入文件不存在：" + input_file_path)

        print("开始分块读取 CSV 文件并匹配 OpenAlex 数据...")
        first_write = True
        total_input = 0
        total_matched = 0

        # 3. 分块读取 CSV
        for chunk_idx, df in enumerate(pd.read_csv(input_file_path, chunksize=chunk_size)):
            print(f"\n正在处理第 {chunk_idx + 1} 块数据（{len(df)} 行）")
            total_input += len(df)

            if 'DOI' not in df.columns:
                raise ValueError("CSV 文件中未找到 'DOI' 列")

            # 清洗 DOI
            doi_list = (
                df['DOI']
                .dropna()
                .astype(str)
                .unique()
                .tolist()
            )

            if not doi_list:
                print("本块中没有有效 DOI，跳过")
                continue

            # 4. MongoDB 查询
            query = {'doi': {'$in': doi_list}}
            results = list(collection.find(query, {'_id': 0}))
            print(f"本块匹配到 {len(results)} 条 OpenAlex 记录")
            total_matched += len(results)

            if results:
                df_results = pd.DataFrame(results)

                # 5. 追加写入 CSV（不会占内存）
                df_results.to_csv(
                    output_file_path,
                    mode='w' if first_write else 'a',
                    index=False,
                    header=first_write
                )
                first_write = False

        print("\n========== 全部处理完成 ==========")
        print(f"输入总行数：{total_input}")
        print(f"匹配到的 OpenAlex 记录数：{total_matched}")
        print(f"输出文件：{output_file_path}")

    except FileNotFoundError as e:
        print("\n文件错误：" + str(e))
    except ValueError as e:
        print("\n数据错误：" + str(e))
    except Exception as e:
        print("\n程序执行出错：" + type(e).__name__ + " - " + str(e))
    finally:
        try:
            client.close()
            print("\nMongoDB连接已关闭")
        except:
            pass

if __name__ == '__main__':
    main()
