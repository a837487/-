import pandas as pd
from pymongo import MongoClient
import os
import json
import ast

# ===================== MongoDB 连接 =====================
print("正在连接MongoDB...")
try:
    client = MongoClient('mongodb://localhost:27017/')
    db = client["OpenAlex-2025"]
    source_collection = db.sources
    print("MongoDB连接成功")
except Exception as e:
    print(f"MongoDB连接失败: {e}")
    source_collection = None

# ===================== 文件路径 =====================
original_file_path = r"D:\所有\桌面\数据集\5.csv"
new_file_path = r"D:\所有\桌面\数据集\6.csv"

chunk_size = 50000  # ★ 核心：分块大小

# ===================== 统计变量 =====================
total_records = 0
success_count = 0
fail_count = 0
success_dois = []

first_write = True  # CSV 追加写入标志

# ===================== 主处理逻辑 =====================
if source_collection is not None:

    print("开始分块读取 CSV 并处理数据...")

    for chunk_idx, df_original in enumerate(pd.read_csv(original_file_path, chunksize=chunk_size)):
        print(f"\n===== 正在处理第 {chunk_idx + 1} 块（{len(df_original)} 条） =====")

        original_data = df_original.to_dict('records')
        total_records += len(original_data)

        source_info = []
        source_ids = []

        # ---------- 第一阶段：提取 source_id ----------
        for item in original_data:
            try:
                doi = item.get('doi', '未知DOI')

                if 'primary_location' in item:
                    primary_location = item['primary_location']

                    if isinstance(primary_location, str):
                        try:
                            primary_location = ast.literal_eval(
                                primary_location.replace('\n', '').replace('\t', '').strip()
                            )
                        except:
                            try:
                                primary_location = json.loads(primary_location.replace("'", "\""))
                            except:
                                continue

                    if isinstance(primary_location, dict) and 'source' in primary_location:
                        source = primary_location['source']

                        if isinstance(source, str):
                            try:
                                source = json.loads(source.replace("'", "\""))
                            except:
                                continue

                        if isinstance(source, dict) and 'id' in source and source['id']:
                            source_info.append((source['id'], doi))

            except:
                continue

        source_ids = [x[0] for x in source_info]

        print(f"成功提取 source_id 数量：{len(source_ids)}")

        if not source_ids:
            continue

        # ---------- 第二阶段：查询 source 集合 ----------
        source_data = list(source_collection.find({'id': {'$in': source_ids}}))
        source_dict = {item['id']: item for item in source_data if 'id' in item}

        # ---------- 第三阶段：添加 source 信息并筛选 ----------
        valid_data = []

        for item in original_data:
            try:
                doi = item.get('doi', '未知DOI')

                if 'primary_location' not in item:
                    fail_count += 1
                    continue

                primary_location = item['primary_location']
                if isinstance(primary_location, str):
                    try:
                        primary_location = ast.literal_eval(
                            primary_location.replace('\n', '').replace('\t', '').strip()
                        )
                    except:
                        try:
                            primary_location = json.loads(primary_location.replace("'", "\""))
                        except:
                            fail_count += 1
                            continue

                if not isinstance(primary_location, dict):
                    fail_count += 1
                    continue

                source = primary_location.get('source')
                if isinstance(source, str):
                    try:
                        source = json.loads(source.replace("'", "\""))
                    except:
                        fail_count += 1
                        continue

                if not isinstance(source, dict) or 'id' not in source:
                    fail_count += 1
                    continue

                source_record = source_dict.get(source['id'])
                if not source_record:
                    fail_count += 1
                    continue

                # ===== 添加 source 字段（完全照你的原逻辑）=====
                item['source_publisher_id'] = source_record.get('publisher_id')
                item['source_issn_nl'] = source_record.get('issn_nl')
                item['source_type'] = source_record.get('type')
                item['source_summary_stats'] = source_record.get('summary_stats')
                item['source_id'] = source_record.get('id')
                item['source_cited_by_count'] = source_record.get('cited_by_count')
                item['source_display_name'] = source_record.get('display_name')
                item['source_host_organization_name'] = source_record.get('host_organization_name')
                item['source_works_count'] = source_record.get('works_count')

                valid_data.append(item)
                success_count += 1
                success_dois.append(doi)

            except:
                fail_count += 1
                continue

        # ---------- 第四阶段：立即写出，防止内存累积 ----------
        if valid_data:
            df_valid = pd.DataFrame(valid_data)
            df_valid.to_csv(
                new_file_path,
                mode='w' if first_write else 'a',
                index=False,
                header=first_write
            )
            first_write = False

# ===================== 最终统计 =====================
print("\n" + "="*60)
print("===== 数据筛选与添加结果统计 =====")
print(f"原始数据总记录数：{total_records}")
print(f"成功添加source信息并保留的记录数：{success_count}")
print(f"被过滤掉的记录数：{fail_count}")
print(f"有效数据保留率：{success_count/total_records*100:.2f}%" if total_records else "0%")
print("="*60)

try:
    client.close()
    print("\nMongoDB连接已关闭")
except:
    pass

print("\n操作完成！")
