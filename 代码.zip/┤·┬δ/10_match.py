
import pandas as pd
import os


def merge_csv_by_doi():
    """
    通过DOI匹配，将 pre_connected_data.csv 中的指定列
    合并到 slimmed_for_analysis.csv 中

    步骤：
    1. 识别并处理数据源表重复 DOI
    2. 按 DOI 左连接
    3. 合并后再次 DOI 去重

    最终保证：
    - DOI 唯一
    - 最终行数 ≤ 目标表原始行数
    """

    # ---------------------- 配置文件路径和列名 ----------------------
    FILE1_PATH = r"D:\所有\桌面\数据集\10.csv"
    FILE2_PATH = r"D:\所有\桌面\数据集\4.csv"
    OUTPUT_PATH = r"D:\所有\桌面\数据集\11.csv"

    COLUMNS_TO_MERGE = [
        'doi',
        'OA Status',
        'News mentions',
        'Number of Dimensions citations',
        'is_news_friendly_discipline',
        'days_since_pub'
    ]

    try:
        # ---------------------- 读取数据 ----------------------
        print(f"正在读取目标表：{FILE1_PATH}")
        df_target = pd.read_csv(FILE1_PATH)
        target_original_rows = len(df_target)
        target_original_doi_count = df_target['doi'].nunique()

        print(f"正在读取数据源表：{FILE2_PATH}")
        df_source = pd.read_csv(FILE2_PATH)

        # ---------------------- 必要列检查 ----------------------
        if 'doi' not in df_target.columns:
            raise ValueError("目标表中缺少 'doi' 列")
        if 'doi' not in df_source.columns:
            raise ValueError("数据源表中缺少 'doi' 列")

        missing_cols = [c for c in COLUMNS_TO_MERGE if c not in df_source.columns]
        if missing_cols:
            print(f"警告：数据源表缺少以下列，将跳过：{missing_cols}")
            COLUMNS_TO_MERGE = [c for c in COLUMNS_TO_MERGE if c in df_source.columns]
            if len(COLUMNS_TO_MERGE) <= 1:
                raise ValueError("无可用的合并列")

        # ---------------------- DOI 清洗 ----------------------
        df_target['doi'] = df_target['doi'].astype(str).str.strip()
        df_source['doi'] = df_source['doi'].astype(str).str.strip()

        # ---------------------- 数据源表重复 DOI 统计 ----------------------
        duplicate_mask_source = df_source['doi'].duplicated(keep=False)
        duplicate_dois_source = df_source.loc[duplicate_mask_source, 'doi'].unique()

        if len(duplicate_dois_source) > 0:
            print("\n【数据源表重复 DOI】")
            print(f"发现 {len(duplicate_dois_source)} 个重复 DOI：")
            for doi in duplicate_dois_source:
                cnt = (df_source['doi'] == doi).sum()
                print(f"DOI: {doi} | 出现次数: {cnt}")
            print(f"重复行总数：{df_source['doi'].duplicated().sum()}")
        else:
            print("\n【数据源表重复 DOI】无重复")

        # ---------------------- 数据源表去重 ----------------------
        df_source_filtered = df_source[COLUMNS_TO_MERGE].copy()
        if len(duplicate_dois_source) > 0:
            df_source_filtered = df_source_filtered.drop_duplicates(
                subset=['doi'], keep='first'
            )
            print(f"数据源表去重后行数：{len(df_source_filtered)}")

        # ---------------------- DOI 左连接 ----------------------
        print("\n正在按 DOI 左连接合并...")
        df_merged = pd.merge(
            df_target,
            df_source_filtered,
            on='doi',
            how='left'
        )

        merge_after_rows = len(df_merged)
        merge_after_doi_count = df_merged['doi'].nunique()

        # ---------------------- 合并后 DOI 再去重 ----------------------
        duplicate_mask_merged = df_merged['doi'].duplicated(keep=False)
        duplicate_dois_merged = df_merged.loc[duplicate_mask_merged, 'doi'].unique()

        if len(duplicate_dois_merged) > 0:
            print(f"\n合并后发现 {len(duplicate_dois_merged)} 个重复 DOI，开始去重")
            df_merged_dedup = df_merged.drop_duplicates(
                subset=['doi'], keep='first'
            )
            print(f"去重移除行数：{len(df_merged) - len(df_merged_dedup)}")
        else:
            df_merged_dedup = df_merged.copy()
            print("\n合并后无重复 DOI")

        # ---------------------- 匹配统计 ----------------------
        merged_cols = COLUMNS_TO_MERGE[1:]
        final_match_success = df_merged_dedup[merged_cols].notna().any(axis=1).sum()
        final_match_failed = len(df_merged_dedup) - final_match_success

        # ---------------------- 保存 CSV ----------------------
        df_merged_dedup.to_csv(OUTPUT_PATH, index=False)

        # ---------------------- 输出统计 ----------------------
        print("\n==================== 最终统计结果 ====================")
        print(f"目标表原始行数：{target_original_rows}")
        print(f"目标表原始唯一 DOI 数：{target_original_doi_count}")
        print(f"合并后（去重前）行数：{merge_after_rows}")
        print(f"合并后（去重前）唯一 DOI 数：{merge_after_doi_count}")
        print(f"最终行数（去重后）：{len(df_merged_dedup)}")
        print(f"最终唯一 DOI 数：{df_merged_dedup['doi'].nunique()}")
        print(f"匹配成功行数：{final_match_success}")
        print(f"匹配失败行数：{final_match_failed}")

        for col in merged_cols:
            print(f"{col} 非空行数：{df_merged_dedup[col].notna().sum()}")

        print(f"\n最终文件已保存至：{os.path.abspath(OUTPUT_PATH)}")

    except FileNotFoundError as e:
        print(f"文件不存在：{e.filename}")
    except ValueError as e:
        print(f"数据错误：{e}")
    except Exception as e:
        print(f"未知错误：{str(e)}")


# ---------------------- 执行入口 ----------------------
if __name__ == "__main__":
    merge_csv_by_doi()
