# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import shap
import matplotlib.pyplot as plt
import os

from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.ensemble import GradientBoostingClassifier
import lightgbm as lgb
import matplotlib
# 设置中文字体为黑体
matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 中文字体
matplotlib.rcParams['axes.unicode_minus'] = False    # 解决负号显示问题

# ===============================
# 1. 参数区
# ===============================
DATA_PATH = r"D:\所有\桌面\11_MLdata.csv"
TARGET = "News mentions"
RANDOM_STATE = 42
TOP_K = [10, 20, 30, 40, 50]
SHAP_SAMPLE_SIZE = 5000       # 抽样5000条计算SHAP
MAX_FEATURES_SHAP = 10        # 绘图显示前10个特征
SHAP_OUTPUT_DIR = r"D:\所有\桌面\SHAP_Images"  # 保存SHAP图文件夹
SHAP_COLOR = "#1f77b4"        # SHAP条形图主色调

# 创建保存目录（如果不存在）
os.makedirs(SHAP_OUTPUT_DIR, exist_ok=True)

# ===============================
# 2. NDCG & 排序指标
# ===============================
def ndcg_at_k(y_sorted, k):
    k = min(k, len(y_sorted))
    gains = y_sorted[:k]
    discounts = 1.0 / np.log2(np.arange(2, k + 2))
    dcg = np.sum(gains * discounts)
    ideal = np.sort(y_sorted)[::-1][:k]
    idcg = np.sum(ideal * discounts)
    return dcg / idcg if idcg > 0 else 0.0

def ranking_metrics(y_true, scores):
    order = np.argsort(-scores)
    y_sorted = y_true.iloc[order].reset_index(drop=True)
    res = {}
    total_pos = y_true.sum()
    n = len(y_true)
    for k in TOP_K:
        top_n = int(n * k / 100)
        res[f"召回率@{k}%"] = y_sorted.iloc[:top_n].sum() / total_pos
        res[f"精确率@{k}%"] = y_sorted.iloc[:top_n].mean()
    res["NDCG@50"] = ndcg_at_k(y_sorted.values, 50)
    res["NDCG@100"] = ndcg_at_k(y_sorted.values, 100)
    return res

# ===============================
# 3. 读取数据 & 划分训练集/测试集
# ===============================
df = pd.read_csv(DATA_PATH)
X = df.drop(columns=[TARGET])
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
)

print("训练集大小:", X_train.shape)
print("测试集大小:", X_test.shape)
print("训练集阳性比例:", y_train.mean())

# ===============================
# 4. 模型定义（GBDT & LightGBM）
# ===============================
models = {
    "GBDT": GradientBoostingClassifier(
        n_estimators=100, max_depth=3, random_state=RANDOM_STATE
    ),
    "LightGBM": lgb.LGBMClassifier(
        objective="binary",
        is_unbalance=True,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        max_depth=6,
        num_leaves=32,
        n_estimators=200,
        learning_rate=0.05
    )
}

# ===============================
# 5. 训练 & 评估 & 自定义 SHAP分析（中文显示）
# ===============================
# 中文特征名映射
feature_name_map = {
    "referenced_works_count": "参考文献数量",
    "Number of Dimensions citations": "被引量",
    "oa_status": "OA状态",
    "is_news_friendly_discipline": "是否新闻友好学科",
    "days_since_pub": "发表时长",
    "countries_distinct_count": "不同国家数量",
    "institutions_distinct_count": "不同机构数量",
    "grants_count": "基金数量",
    "authors_count": "合作者数量",
    "first_author_works_count": "第一作者作品数",
    "first_author_cited_by_count": "第一作者被引量",
    "first_author_h_index": "第一作者h指数",
    "first_author_i10_index": "第一作者i10指数",
    "first_author_2yr_h_index": "第一作者近2年h指数",
    "first_author_2yr_i10_index": "第一作者近2年i10指数",
    "source_works_count": "来源期刊作品数",
    "source_cited_by_count": "来源期刊被引量",
    "source_h_index": "来源期刊h指数",
    "source_i10_index": "来源期刊i10指数",
    "source_2yr_h_index": "来源期刊近2年h指数",
    "source_2yr_i10_index": "来源期刊近2年i10指数",
    "first_institution_works_count": "第一作者机构论文数",
    "first_institution_cited_by_count": "第一作者机构被引量",
    "first_institution_h_index": "第一作者机构h指数",
    "first_institution_i10_index": "第一作者机构i10指数",
    "first_institution_2yr_h_index": "第一作者机构近2年h指数",
    "first_institution_2yr_i10_index": "第一作者机构近2年i10指数"
}

results = []

for model_name, model in models.items():
    try:
        print(f"\n=== 训练模型: {model_name} ===")
        model.fit(X_train, y_train)
        scores = model.predict_proba(X_test)[:, 1]

        # 评估指标
        row = {
            "模型": model_name,
            "ROC-AUC": roc_auc_score(y_test, scores),
            "PR-AUC": average_precision_score(y_test, scores)
        }
        row.update(ranking_metrics(y_test, scores))
        results.append(row)

        # ===============================
        # SHAP特征重要性分析（中文显示）
        # ===============================
        print(f"\n=== SHAP分析: {model_name} (抽样 {SHAP_SAMPLE_SIZE} 条) ===")
        sample_idx = np.random.choice(X_test.shape[0], SHAP_SAMPLE_SIZE, replace=False)
        X_test_sample = X_test.iloc[sample_idx]

        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_test_sample)

        # 平均绝对SHAP值
        if isinstance(shap_values, list):  # LightGBM二分类返回list
            shap_values_abs = np.abs(shap_values[1])
        else:
            shap_values_abs = np.abs(shap_values)
        shap_mean = np.mean(shap_values_abs, axis=0)

        # 转中文特征名
        feature_importance = pd.DataFrame({
            "特征": [feature_name_map.get(f, f) for f in X_test_sample.columns],
            "重要性": shap_mean
        }).sort_values(by="重要性", ascending=False).head(MAX_FEATURES_SHAP)

        # 水平条形图
        plt.figure(figsize=(8, 6))
        plt.barh(
            feature_importance["特征"][::-1],
            feature_importance["重要性"][::-1],
            color=SHAP_COLOR
        )
        plt.xlabel("重要性")
        plt.ylabel("特征")
        plt.title(f"{model_name} 特征重要性")
        plt.xticks(np.arange(0, feature_importance["重要性"].max() + 0.05, 0.05))
        plt.tight_layout()

        # 保存 PNG + PDF
        png_file = os.path.join(SHAP_OUTPUT_DIR, f"{model_name}_SHAP.png")
        pdf_file = os.path.join(SHAP_OUTPUT_DIR, f"{model_name}_SHAP.pdf")
        plt.savefig(png_file, dpi=300)
        plt.savefig(pdf_file)
        plt.close()
        print(f"SHAP图保存完成: {png_file} , {pdf_file}")

    except Exception as e:
        print(f"模型 {model_name} 训练/评估/SHAP分析失败: {e}")

# ===============================
# 6. 输出最终结果
# ===============================
if results:
    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values(
        by=["NDCG@100", "召回率@10%"],
        ascending=False
    )

    output_path = r"D:\所有\桌面\Ranking_Comparison_Results_SHAP.csv"
    results_df.to_csv(output_path, index=False)

    print("\n===== 最终结果 (前10行) =====")
    print(results_df.round(3).head(10))
    print(f"\n结果已保存至: {output_path}")
else:
    print("所有模型训练失败，没有结果输出。")