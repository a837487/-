import pandas as pd
from pymongo import MongoClient
import os
import json
import ast

# ===================== 1. MongoDB 连接 =====================
print("正在连接MongoDB...")
client = MongoClient('mongodb://localhost:27017/')
db = client['OpenAlex-2025']
authors_collection = db.authors
print("MongoDB连接成功")

# ===================== 2. 文件路径（CSV） =====================
input_file_path = r"D:\所有\桌面\数据集\6.csv"
output_file_path = r"D:\所有\桌面\数据集\7.csv"

chunk_size = 50000  # 核心：分块大小
first_write = True  # CSV 追加写入控制

# ===================== 3. 全局统计 =====================
total_records = 0
success_count = 0
failed_total = 0

# ===================== 4. 分块处理 CSV =====================
print("开始分块读取 CSV 并处理作者信息...")

for chunk_idx, df_original in enumerate(pd.read_csv(input_file_path, chunksize=chunk_size)):
    print(f"\n===== 正在处理第 {chunk_idx + 1} 块（{len(df_original)} 条） =====")

    matched_data = df_original.to_dict('records')
    total_records += len(matched_data)

    author_info = []
    failed_dois = []

    # ---------- 4.1 提取第一作者 ----------
    for idx, item in enumerate(matched_data):
        try:
            doi = item.get('doi', '未知DOI')

            if 'authorships' not in item:
                print(f"doi：{doi}，原因：缺少authorships字段（无作者信息）")
                failed_dois.append(doi)
                continue

            if isinstance(item['authorships'], str):
                clean_auths = item['authorships'].replace('\n', '').replace('\t', '').strip()
                try:
                    item['authorships'] = ast.literal_eval(clean_auths)
                except:
                    try:
                        item['authorships'] = json.loads(clean_auths.replace("'", "\""))
                    except:
                        print(f"doi：{doi}，原因：authorships字符串无法解析")
                        failed_dois.append(doi)
                        continue

            if not isinstance(item['authorships'], list) or len(item['authorships']) == 0:
                print(f"doi：{doi}，原因：authorships非列表或为空")
                failed_dois.append(doi)
                continue

            first_author = item['authorships'][0]

            if 'author' not in first_author:
                print(f"doi：{doi}，原因：第一作者中缺少author字段")
                failed_dois.append(doi)
                continue

            author = first_author['author']
            if 'id' not in author or not author['id']:
                print(f"doi：{doi}，原因：第一作者author中缺少id")
                failed_dois.append(doi)
                continue

            author_info.append((author['id'], doi, idx))

        except Exception as e:
            print(f"doi：{doi}，原因：处理authorships异常 - {str(e)}")
            failed_dois.append(doi)
            continue

    failed_total += len(failed_dois)

    # ---------- 4.2 查询 authors 集合 ----------
    author_ids = [x[0] for x in author_info]
    print(f"提取作者ID数量：{len(author_ids)}，唯一：{len(set(author_ids))}")

    if not author_ids:
        continue

    authors_data = list(authors_collection.find({'id': {'$in': author_ids}}))
    authors_dict = {item['id']: item for item in authors_data if 'id' in item}

    # ---------- 4.3 合并作者信息 ----------
    valid_data = []

    for author_id, doi, idx in author_info:
        try:
            item = matched_data[idx]
            author_record = authors_dict.get(author_id)

            if not author_record:
                print(f"doi：{doi}，原因：无匹配作者记录（{author_id}）")
                continue

            item['first_author_id'] = author_record.get('id')
            item['first_author_display_name'] = author_record.get('display_name')
            item['first_author_works_count'] = author_record.get('works_count')
            item['first_author_cited_by_count'] = author_record.get('cited_by_count')
            item['first_author_summary_stats'] = author_record.get('summary_stats')

            valid_data.append(item)
            success_count += 1

            if success_count % 100 == 0:
                print(f"已成功合并 {success_count} 条（当前doi：{doi}）")

        except Exception as e:
            print(f"doi：{doi}，原因：合并异常 - {str(e)}")
            continue

    # ---------- 4.4 立即写出 CSV ----------
    if valid_data:
        df_valid = pd.DataFrame(valid_data)
        df_valid.to_csv(
            output_file_path,
            mode='w' if first_write else 'a',
            index=False,
            header=first_write
        )
        first_write = False

# ===================== 5. 最终统计 =====================
print("\n" + "="*60)
print("===== 作者信息合并完成 =====")
print(f"原始数据总量：{total_records}")
print(f"成功合并作者信息：{success_count}")
print(f"作者解析失败数量：{failed_total}")
print("="*60)

client.close()
print("MongoDB连接已关闭")
print("所有操作完成！")
