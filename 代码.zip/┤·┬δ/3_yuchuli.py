# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import re
from collections import Counter

# ============================
# 1. 路径与列名
# ============================
file_path = r"D:\所有\桌面\数据集\3.csv"
subject_col = "Subjects (FoR)"

# ============================
# 2. 读取数据
# ============================
df = pd.read_csv(file_path, low_memory=False)

# ============================
# 3. OA Status 转换（TRUE/FALSE → 1/0）
# ============================
df["OA Status"] = df["OA Status"].map({"TRUE": 1, "FALSE": 0})

# 如果存在缺失或异常值，填充为0（可选）
df["OA Status"] = df["OA Status"].fillna(0).astype(int)

# ============================
# 4. 处理 Publication Date
# ============================
df['Publication Date'] = pd.to_datetime(df['Publication Date'], errors='coerce')

# 检查无效日期
invalid_dates = df['Publication Date'].isna().sum()
print(f"无效日期数量: {invalid_dates}")

# 计算距检索日天数
ref_date = pd.Timestamp("2026-01-13")
df['days_since_pub'] = (ref_date - df['Publication Date']).dt.days
df['days_since_pub'] = df['days_since_pub'].clip(lower=0)
df['days_since_pub'].fillna(0, inplace=True)

# ============================
# 5. 提取一级学科函数
# ============================
def extract_top_fields(subject_str):
    if pd.isna(subject_str):
        return []

    parts = [p.strip() for p in subject_str.split(";")]
    top_fields = []

    for p in parts:
        m = re.match(r"\d+\s+(.+)", p)
        if m:
            field = m.group(1).strip()
            top_fields.append(field)

    return list(set(top_fields))  # 去重

# ============================
# 6. 构造新闻友好学科（二分类）
# ============================
news_friendly_disciplines = {
    "Biomedical and Clinical Sciences",
    "Health Sciences",
    "Biological Sciences",
    "Psychology",
}

is_news_friendly_list = []

for s in df[subject_col]:
    fields = extract_top_fields(s)

    if len(fields) == 0:
        is_news_friendly_list.append(0)
    else:
        is_news_friendly_list.append(
            int(any(f in news_friendly_disciplines for f in fields))
        )

df["is_news_friendly_discipline"] = is_news_friendly_list

# ============================
# 7. 一级学科统计（可选）
# ============================
all_top_fields = []
for s in df[subject_col]:
    all_top_fields.extend(extract_top_fields(s))

counter = Counter(all_top_fields)

field_df = (
    pd.DataFrame(counter.items(), columns=["Top-level Field", "Count"])
    .sort_values("Count", ascending=False)
    .reset_index(drop=True)
)

print(f"共发现 {len(field_df)} 个不同的一级学科：\n")
print(field_df.head(20))

# ============================
# 8. 删除原始列（重要）
# ============================
df.drop(columns=[subject_col, "Publication Date"], inplace=True)

# ============================
# 9. 保存结果
# ============================
output_path = r"D:\所有\桌面\数据集\4.csv"
df.to_csv(output_path, index=False)

print(f"\n处理完成，新文件已保存：{output_path}")

# ============================
# 10. 分布检查
# ============================
print("\nis_news_friendly_discipline 分布：")
print(df["is_news_friendly_discipline"].value_counts())

if "News mentions" in df.columns:
    print("\n不同学科类型的新闻提及率：")
    print(
        df.groupby("is_news_friendly_discipline")["News mentions"].mean()
    )