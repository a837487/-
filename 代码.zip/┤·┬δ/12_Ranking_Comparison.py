# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, StackingClassifier
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.neural_network import MLPClassifier

from xgboost import XGBClassifier
import lightgbm as lgb
from catboost import CatBoostClassifier
from pytorch_tabnet.tab_model import TabNetClassifier

import torch

# ===============================
# 1. 参数区
# ===============================
DATA_PATH = r"D:\所有\桌面\11_MLData.csv"
TARGET = "News mentions"

TOP_K = [10, 20, 30, 40, 50]
RANDOM_STATE = 42

# ===============================
# 2. NDCG & Ranking Metrics
# ===============================
def ndcg_at_k(y_sorted, k):
    k = min(k, len(y_sorted))
    gains = y_sorted[:k]
    discounts = 1.0 / np.log2(np.arange(2, k + 2))
    dcg = np.sum(gains * discounts)
    ideal = np.sort(y_sorted)[::-1][:k]
    idcg = np.sum(ideal * discounts)
    return dcg / idcg if idcg > 0 else 0.0

def ranking_metrics(y_true, scores):
    order = np.argsort(-scores)
    y_sorted = y_true.iloc[order].reset_index(drop=True)
    res = {}
    total_pos = y_true.sum()
    n = len(y_true)
    for k in TOP_K:
        top_n = int(n * k / 100)
        res[f"Recall@{k}%"] = y_sorted.iloc[:top_n].sum() / total_pos
        res[f"Precision@{k}%"] = y_sorted.iloc[:top_n].mean()
    res["NDCG@50"] = ndcg_at_k(y_sorted.values, 50)
    res["NDCG@100"] = ndcg_at_k(y_sorted.values, 100)
    return res

# ===============================
# 3. 读取数据 & 划分
# ===============================
df = pd.read_csv(DATA_PATH)
X = df.drop(columns=[TARGET])
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, stratify=y, random_state=RANDOM_STATE
)

print("Train size:", X_train.shape)
print("Test size:", X_test.shape)
print("Positive rate (train):", y_train.mean())

# ===============================
# 4. 模型定义（轻量，控制内存）
# ===============================
models = {
    "Logistic": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=500, class_weight="balanced"))
    ]),

    "LinearSVM": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", CalibratedClassifierCV(
            base_estimator=LinearSVC(class_weight="balanced", max_iter=5000),
            cv=3
        ))
    ]),

    "RandomForest": RandomForestClassifier(
        n_estimators=100, max_depth=10, min_samples_leaf=10,
        class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
    ),

    "GBDT": GradientBoostingClassifier(
        n_estimators=100, max_depth=3, random_state=RANDOM_STATE
    ),

    "XGBoost": XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        scale_pos_weight=(y_train == 0).sum() / (y_train == 1).sum(),
        random_state=RANDOM_STATE,
        n_jobs=-1,
        max_depth=4,
        learning_rate=0.05,
        n_estimators=100
    ),

    "LightGBM": lgb.LGBMClassifier(
        objective="binary",
        is_unbalance=True,
        random_state=RANDOM_STATE,
        n_jobs=-1,
        max_depth=6,
        num_leaves=32,
        n_estimators=200,
        learning_rate=0.05
    ),

    "CatBoost": CatBoostClassifier(
        iterations=200,
        depth=6,
        learning_rate=0.05,
        loss_function='Logloss',
        eval_metric='AUC',
        verbose=0,
        random_seed=RANDOM_STATE,
        class_weights=[(y_train==0).sum(), (y_train==1).sum()]
    ),

    "MLP": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", MLPClassifier(
            hidden_layer_sizes=(64, 32),
            activation='relu',
            solver='adam',
            alpha=0.0005,
            batch_size=512,
            learning_rate_init=0.01,
            max_iter=200,
            random_state=RANDOM_STATE,
            early_stopping=True,
            n_iter_no_change=10
        ))
    ]),

    "Stacking": StackingClassifier(
        estimators=[
            ("lr", LogisticRegression(max_iter=500, class_weight="balanced")),
            ("rf", RandomForestClassifier(
                n_estimators=50, max_depth=8, min_samples_leaf=10,
                class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
            )),
            ("gbdt", GradientBoostingClassifier(n_estimators=50, max_depth=3, random_state=RANDOM_STATE))
        ],
        final_estimator=LogisticRegression(max_iter=500),
        n_jobs=-1,
        passthrough=True
    ),

    "TabNet": None  # 单独处理
}

# ===============================
# 5. 训练 & 评估
# ===============================
results = []

for model_name, model in models.items():
    try:
        print(f"\n=== Training {model_name} ===")
        if model_name == "TabNet":
            clf = TabNetClassifier(
                n_d=16, n_a=16, n_steps=3,
                gamma=1.3,
                optimizer_fn=torch.optim.Adam,
                optimizer_params=dict(lr=2e-2),
                seed=RANDOM_STATE,
                verbose=0,
                mask_type='sparsemax'
            )
            clf.fit(
                X_train.values, y_train.values,
                eval_set=[(X_test.values, y_test.values)],
                eval_metric=["auc"],
                patience=10,
                batch_size=512,
                max_epochs=50
            )
            scores = clf.predict_proba(X_test.values)[:, 1]
        else:
            model.fit(X_train, y_train)
            scores = model.predict_proba(X_test)[:, 1]

        # 评估
        row = {
            "Model": model_name,
            "ROC-AUC": roc_auc_score(y_test, scores),
            "PR-AUC": average_precision_score(y_test, scores)
        }
        row.update(ranking_metrics(y_test, scores))
        results.append(row)

    except Exception as e:
        print(f"模型 {model_name} 训练/评估失败: {e}")

# ===============================
# 6. 输出结果
# ===============================
if results:
    results_df = pd.DataFrame(results)
    results_df = results_df.sort_values(
        by=["NDCG@100", "Recall@10%"],
        ascending=False
    )

    output_path = r"D:\所有\桌面\Ranking_Comparison_Results_1.csv"
    results_df.to_csv(output_path, index=False)

    print("\n===== Final Results (Top Rows) =====")
    print(results_df.round(3).head(10))
    print(f"\nResults saved to: {output_path}")
else:
    print("所有模型都训练失败，没有结果输出。")