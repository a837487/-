import pandas as pd

# 1. 读取数据
file_path = r"D:\所有\桌面\数据集\2.csv"
df = pd.read_csv(file_path)

# 2. 分离两类
df_0 = df[df['News mentions'] == 0]
df_1 = df[df['News mentions'] == 1]

# 3. 下采样：从 0 中随机抽取与 1 数量相同的样本
df_0_downsampled = df_0.sample(
    n=len(df_1),
    random_state=42  # 固定随机种子，结果可复现
)

# 4. 合并并打乱
df_balanced = pd.concat([df_0_downsampled, df_1], axis=0)
df_balanced = df_balanced.sample(frac=1, random_state=42).reset_index(drop=True)

# 5. 保存新数据
output_path = r"D:\所有\桌面\数据集\3.csv"
df_balanced.to_csv(output_path, index=False)

# 6. 打印类别分布
print("原始类别分布：")
print(df['News mentions'].value_counts())
print("\n平衡后类别分布：")
print(df_balanced['News mentions'].value_counts())
