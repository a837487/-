import pandas as pd
import numpy as np

# 定义文件路径
input_path = r"D:\所有\桌面\data\1.csv"
output_path = r"D:\所有\桌面\data\2.csv"

# 1. 读取CSV文件
# 注意：表头可能有特殊字符，设置keep_default_na=False避免将空字符串识别为NaN
df = pd.read_csv(input_path, keep_default_na=False)

# 2. 定义需要保留的列名
target_columns = [
    "DOI",
    "Subjects (FoR)",
    "Publication Date",
    "OA Status",
    "News mentions",
    "Number of Dimensions citations"
]

# 检查列名是否存在，避免KeyError
missing_cols = [col for col in target_columns if col not in df.columns]
if missing_cols:
    raise ValueError(f"CSV文件中缺少以下必要列：{missing_cols}")

# 提取目标列
df_target = df[target_columns].copy()

# 3. 处理空值（删除DOI或News mentions为空的行，并打印缺失信息）
# 先将空字符串、空格等转为标准NaN
df_target = df_target.replace(['', ' ', '  '], np.nan)

# 遍历每一行，检查缺失值并打印
rows_to_drop = []
for idx, row in df_target.iterrows():
    missing_fields = []
    # 检查DOI是否为空
    if pd.isna(row['DOI']):
        missing_fields.append('DOI')
    # 检查News mentions是否为空
    if pd.isna(row['News mentions']):
        missing_fields.append('News mentions')
    # 检查Subject是否为空
    if pd.isna(row['Subjects (FoR)']):
        missing_fields.append('Subjects (FoR)')

    # 如果有缺失字段，记录并打印
    if missing_fields:
        print(f"行索引 {idx} 缺失字段：{', '.join(missing_fields)}")
        print(f"该行完整数据：\n{row.to_dict()}\n")
        rows_to_drop.append(idx)

# 删除有缺失值的行
df_clean = df_target.drop(rows_to_drop).reset_index(drop=True)

# 4. 将News mentions非0值转为1（先确保该列是数值类型）
# 处理可能的非数值类型（如字符串'0'、'5'等）
df_clean['News mentions'] = pd.to_numeric(df_clean['News mentions'], errors='coerce')

# 替换逻辑：非0值→1，0值保持0
df_clean['News mentions'] = df_clean['News mentions'].apply(lambda x: 1 if x != 0 else 0)

# 5. 保存处理后的文件
df_clean.to_csv(output_path, index=False, encoding='utf-8-sig')

print(f"\n数据预处理完成！")
print(f"原始数据行数：{len(df_target)}")
print(f"清洗后数据行数：{len(df_clean)}")
print(f"删除的行数：{len(rows_to_drop)}")
print(f"处理后文件已保存至：{output_path}")