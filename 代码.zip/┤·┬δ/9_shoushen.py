import pandas as pd
import os

# ====================== 配置 ======================
input_file = r"D:\所有\桌面\数据集\9.csv"
output_file = r"D:\所有\桌面\数据集\10.csv"

chunksize = 10000  # 每次读取1万行，内存安全
# =================================================

# 你需要保留的列
required_columns = [
    "doi",
    "countries_distinct_count",
    "institutions_distinct_count",
    "cited_by_count",
    "referenced_works_count",
    "authors_count",
    "source_cited_by_count",
    "source_works_count",
    "first_author_works_count",
    "first_author_cited_by_count",
    "first_institution_works_count",
    "first_institution_cited_by_count",
    "grants_count",
    "source_h_index",
    "source_i10_index",
    "source_2yr_h_index",
    "source_2yr_i10_index",
    "first_author_h_index",
    "first_author_i10_index",
    "first_author_2yr_h_index",
    "first_author_2yr_i10_index",
    "first_institution_2yr_h_index",
    "first_institution_2yr_i10_index",
    "first_institution_h_index",
    "first_institution_i10_index"
]

# 如果输出文件存在，先删除
if os.path.exists(output_file):
    os.remove(output_file)

print("开始按需列读取并瘦身 CSV ...")

total_rows = 0
written_rows = 0

for chunk in pd.read_csv(input_file, chunksize=chunksize, encoding="utf-8"):
    total_rows += len(chunk)

    # 只保留当前 chunk 中真实存在的列（防止缺列报错）
    existing_cols = [c for c in required_columns if c in chunk.columns]
    slim_chunk = chunk[existing_cols]

    slim_chunk.to_csv(
        output_file,
        mode="a",
        index=False,
        header=not os.path.exists(output_file),
        encoding="utf-8"
    )

    written_rows += len(slim_chunk)
    print(f"已处理 {total_rows} 行，已写入 {written_rows} 行")

print("\n处理完成！")
print(f"最终输出文件：{output_file}")
print(f"保留列数：{len(existing_cols)}")
