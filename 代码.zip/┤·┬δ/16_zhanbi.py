"""分类统计"""
import pandas as pd

# 1. Excel文件路径
excel_file = r"D:\所有\桌面\工作簿2.xlsx"

# 2. 读取数据
df = pd.read_excel(excel_file)

# 3. 按类别统计标注为1的占比
category_ratio = df.groupby('编码')['标注'].mean().reset_index()
category_ratio['占比(%)'] = category_ratio['标注'] * 100

# 4. 按占比从高到低排序
category_ratio = category_ratio.sort_values(by='占比(%)', ascending=False)

# 5. 输出每个类别的占比
print("各类别标注为1的占比（从高到低）：")
print(category_ratio[['编码', '占比(%)']])

# 6. 计算整体标注为1的比例
overall_ratio = df['标注'].mean() * 100
print(f"\n整体标注为1的占比：{overall_ratio:.2f}%")

# 7. 保存结果到Excel（可选）
category_ratio.to_excel(r"D:\所有\桌面\标注.xlsx", index=False)


import matplotlib.pyplot as plt
import pandas as pd
from adjustText import adjust_text

# 中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 数据
data = {
"编码":[
"研究结论","主要研究结果","未来研究方向","结果解读","启示与建议",
"研究意义/创新点与贡献","研究对象/数据","核心方法论","总体研究内容",
"研究目标","技术/步骤","研究背景","已有研究成果","研究空白",
"研究局限性","研究假设","次要研究结果"
],

"Recall":[
78,68.75,62.5,59.57,52.94,50,43.75,40,35,33.33,33.33,
32.89,27.59,25,20,0,0
],

"占比":[
10.03,30.85,2.43,8.66,3.65,1.82,5.62,2.89,3.50,2.74,
2.28,14.59,6.53,1.52,1.67,0.15,1.06
]
}

df = pd.DataFrame(data)

# 计算均值（象限分割线）
mean_recall = df["Recall"].mean()
mean_share = df["占比"].mean()

# 画布
fig, ax = plt.subplots(figsize=(13,10))

# 四象限背景
ax.axvspan(mean_share, df["占比"].max()+3, mean_recall, df["Recall"].max()+10, color="#e8f1fb", alpha=0.5)
ax.axvspan(0, mean_share, mean_recall, df["Recall"].max()+10, color="#f2f7fd", alpha=0.5)
ax.axvspan(0, mean_share, 0, mean_recall, color="#f8fbff", alpha=0.5)
ax.axvspan(mean_share, df["占比"].max()+3, 0, mean_recall, color="#eef5ff", alpha=0.5)

# 散点
ax.scatter(
df["占比"],
df["Recall"],
color="#1f77b4",
s=140,
edgecolor="white",
linewidth=1,
zorder=3
)

# 标签
texts=[]
for i,row in df.iterrows():
    texts.append(
        ax.text(
            row["占比"],
            row["Recall"],
            row["编码"],
            fontsize=10
        )
    )

# 自动避让
adjust_text(
texts,
arrowprops=dict(
arrowstyle="-",
color="gray",
lw=0.6,
alpha=0.6
)
)

# 象限分割线
ax.axvline(mean_share, linestyle="--", color="gray", linewidth=1)
ax.axhline(mean_recall, linestyle="--", color="gray", linewidth=1)

# 坐标轴
ax.set_xlabel("新闻引用占比 (%)", fontsize=13)
ax.set_ylabel("类别 Recall (%)", fontsize=13)

# 网格
ax.grid(alpha=0.25)

# 象限说明（角落固定 + 背景框）
box_style = dict(
boxstyle="round,pad=0.3",
facecolor="white",
edgecolor="gray",
alpha=0.7
)

ax.text(
0.02,0.96,
"低占比\n高Recall",
transform=ax.transAxes,
fontsize=11,
verticalalignment="top",
bbox=box_style
)

ax.text(
0.98,0.96,
"高占比\n高Recall",
transform=ax.transAxes,
fontsize=11,
horizontalalignment="right",
verticalalignment="top",
bbox=box_style
)

ax.text(
0.02,0.12,
"低占比\n低Recall",
transform=ax.transAxes,
fontsize=11,
verticalalignment="bottom",
bbox=box_style
)

ax.text(
0.98,0.04,
"高占比\n低Recall",
transform=ax.transAxes,
fontsize=11,
horizontalalignment="right",
verticalalignment="bottom",
bbox=box_style
)

plt.tight_layout()

# 保存高清图片
plt.savefig(
r"D:\所有\桌面\Figure_2.png",
dpi=1000,
bbox_inches="tight"
)

plt.show()